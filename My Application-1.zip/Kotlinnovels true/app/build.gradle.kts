plugins {
    alias(libs.plugins.androidApplication)
    alias(libs.plugins.jetbrainsKotlinAndroid)
    id("kotlin-kapt")
}

android {

    namespace = "com.mala.novel"


    compileSdk = 34

    defaultConfig {
        buildFeatures {
            viewBinding = true
        }

        applicationId = "com.mala.novel"

      
        minSdk = 24
        //noinspection OldTargetApi,EditedTargetSdkVersion
        targetSdk = 34
        versionCode = 33
        versionName = "3.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
}

dependencies {

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.android.pdf.viewer)
    implementation(libs.play.services.ads)
    implementation(libs.glide)
    kapt(libs.compiler)

    implementation(libs.lottie)
    // val lifecycle_version = "2.5.1"
    implementation(libs.androidx.lifecycle.viewmodel)
    implementation(libs.lifecycle.viewmodel.ktx)
    // val room_version = "2.6.1"
    implementation(libs.androidx.room.runtime)
    annotationProcessor(libs.room.compiler)
    kapt(libs.room.compiler)
    implementation(libs.room.ktx)
    implementation("androidx.lifecycle:lifecycle-process:2.8.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.6.4")
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)


    // OkHttp for HTTP requests
    implementation ("com.squareup.okhttp3:okhttp:4.9.0")

    // Jsoup for parsing HTML
    implementation ("org.jsoup:jsoup:1.15.3")

    implementation ("com.google.code.gson:gson:2.11.0")

}