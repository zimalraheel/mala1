package com.mala.novel

import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.SimpleItemAnimator
import com.google.gson.Gson
import com.mala.novel.adapter.HomeAdapter
import com.mala.novel.adapter.LAYOUT_BOD
import com.mala.novel.databinding.ActivityMainBinding
import com.mala.novel.model.HomeModel
import com.mala.novel.repository.AllBooksModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Document

private const val MALA_BOOKS = "malaBooks"
private const val NIMRA_BOOKS = "nimraBooks"
private const val UMAIRA_BOOKS = "umairaBooks"
private const val YUSRA_BOOKS = "yusraBooks"
private const val EDITN_BOOKS = "editBooks"
private const val NOVLET_BOOKS = "novletBooks"
private const val AFSNA_BOOKS = "afsanaBooks"

class MainActivity : AppCompatActivity() {



    lateinit var binding: ActivityMainBinding

    val activity = this
    val list: ArrayList<HomeModel> = ArrayList()
    val adapter = HomeAdapter(list, activity)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        binding.apply {
            mRvHome.adapter = adapter

            val malalist = ArrayList<BooksModel>()
            val nimralist = ArrayList<BooksModel>()
            val umairalist = ArrayList<BooksModel>()
            val yusralist = ArrayList<BooksModel>()
            val noveletlist = ArrayList<BooksModel>()
            val afsanalist = ArrayList<BooksModel>()


            malalist.clear()
            malalist.addAll(getBooksData(MALA_BOOKS))
            malalist.forEachIndexed { index, it ->
                // here  need to make sure that
                it.imageRes = malaImageRes.reversed()[index]
            }
            nimralist.clear()
            nimralist.addAll(getBooksData(NIMRA_BOOKS))
            nimralist.forEachIndexed { index, it ->
                // here  need to make sure that
                it.imageRes = nimraImageRes.reversed()[index]
            }
            umairalist.clear()
            umairalist.addAll(getBooksData(UMAIRA_BOOKS))
            umairalist.forEachIndexed { index, it ->
                // here  need to make sure that
                  it.imageRes = umairaImageRes.reversed()[index]
            }
            yusralist.clear()
            yusralist.addAll(getBooksData(YUSRA_BOOKS))
            yusralist.forEachIndexed { index, it ->
                // here  need to make sure that
                it.imageRes = yusraImageRes.reversed()[index]
            }

            noveletlist.clear()
            noveletlist.addAll(getBooksData(NOVLET_BOOKS))
            noveletlist.forEachIndexed { index, it ->
                // here  need to make sure that
                it.imageRes = novletImageRes.reversed()[index]
            }
            afsanalist.clear()
            afsanalist.addAll(getBooksData(AFSNA_BOOKS))
            afsanalist.forEachIndexed { index, it ->
                // here  need to make sure that
                it.imageRes = afsanaImageRes.reversed()[index]
            }


            adapter.notifyItemRangeChanged(0, list.size)

            startParsingPdf(malalist, 1)
            startParsingPdf(nimralist, 2)
            startParsingPdf(umairalist, 3)
            startParsingPdf(yusralist, 4)
            startParsingPdf(afsanalist, 5)
            startParsingPdf(noveletlist, 6)

             list.add(
                HomeModel(
                    catTitle = "Mala Novel All Episodes",
                    booksList = malalist   )  )
            list.add(
                HomeModel(
                    catTitle = "Nimrah Ahmed Novels",
                    booksList = nimralist
                )
            )
            list.add(
                HomeModel(
                    catTitle = "Umaira Ahmed Novels",
                    booksList = umairalist))
            list.add(
                HomeModel(
                    catTitle = "Usri Yusra Novel",
                    booksList = yusralist))


            list.add(
                HomeModel(
                    catTitle = "Afsany",
                    booksList = afsanalist
                )
            )
            list.add(
                HomeModel(
                    catTitle = "Novelt",
                    booksList = noveletlist
                )
            )


            (mRvHome.itemAnimator as SimpleItemAnimator).supportsChangeAnimations = false
        }

    }

    private fun startParsingPdf(bookList: ArrayList<BooksModel>,outerPos : Int) {
        lifecycleScope.launch {

            for ((index, book) in bookList.withIndex()) {
                val downloadPdf = getFinalUrl(book.bookPdf)
                val updatedBook = book.copy(bookPdf = downloadPdf, isPdfAvailable = true)
                withContext(Dispatchers.Main) {
                    bookList[index] = updatedBook
                    adapter.notifyInnerAdapter(binding.mRvHome,outerPos,index) 
                }
            }
        }
    }
    private suspend fun getFinalUrl(url: String): String = withContext(Dispatchers.IO) {
        var finalUrl = ""
        try {
            val request = Request.Builder().url(url).build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e("TAG", "Failed to get initial response for URL: $url")

                    return@use finalUrl
                }

                val html = response.body?.string() ?: return@use finalUrl
                val doc: Document = Jsoup.parse(html)

                val linkToClick = doc.select("a#downloadButton.input.popsok").attr("href")

                if (linkToClick.isNotEmpty()) {
                    Log.d("TAG", "Found link: $linkToClick")

                    val followUpRequest = Request.Builder().url(linkToClick).build()

                    client.newCall(followUpRequest).execute().use { followUpResponse ->
                        if (followUpResponse.isSuccessful) {
                            finalUrl = followUpResponse.request.url.toString()
                        } else {
                            Log.d("TAG", "Failed to follow the link: $linkToClick")
                        }
                    }
                } else {
                    Log.d("TAG", "No link found with selector: for this url is $url")
                }
            }
        } catch (e: Exception) {
            Log.e("TAG", "Exception during URL resolution: ${e.message}", e)
        }
        return@withContext finalUrl
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    private fun getBooksData(bookType: String): ArrayList<BooksModel> {
        val jsonString = assets.open("allNovels.json").bufferedReader()
            .use { it.readText() }
        val allBooksModel = Gson().fromJson(jsonString, AllBooksModel::class.java)
        return when (bookType) {
            MALA_BOOKS -> {
                allBooksModel.malaBooks
            }
            NIMRA_BOOKS -> {
                allBooksModel.nimraBooks
            }
            UMAIRA_BOOKS -> {
                allBooksModel.umairaBooks
            }
            YUSRA_BOOKS -> {
                allBooksModel.yusraBooks
            }
            EDITN_BOOKS-> {
                allBooksModel.novletBooks
            }
            NOVLET_BOOKS-> {
                allBooksModel.novletBooks
            }
            AFSNA_BOOKS -> {
                allBooksModel.afsanaBooks
            }
            else -> arrayListOf()
        }
    }
    private val malaImageRes = listOf(
        R.drawable.mala1, R.drawable.mala2, R.drawable.mala3, R.drawable.mala4,
        R.drawable.mala5, R.drawable.mala6, R.drawable.mala7, R.drawable.mala8,
        R.drawable.mala9, R.drawable.mala10, R.drawable.mala11, R.drawable.mala12,
        R.drawable.mala13, R.drawable.mala14, R.drawable.mala15, R.drawable.mala16,
        R.drawable.mala17, R.drawable.mala18, R.drawable.mala19, R.drawable.mala20,
        R.drawable.mala21, R.drawable.mala22, R.drawable.mala23, R.drawable.mala24,
        R.drawable.mala25, R.drawable.mala26, R.drawable.mala27, R.drawable.mala28,
        R.drawable.mala29, R.drawable.mala30, R.drawable.mala31, R.drawable.mala32,
        R.drawable.mala33, R.drawable.mala34, R.drawable.mala35)
    private val umairaImageRes = listOf(
        R.drawable.aby, R.drawable.aohum, R.drawable.abmera, R.drawable.abhito,
        R.drawable.aisa, R.drawable.aks, R.drawable.alif, R.drawable.amrbail,
        R.drawable.bat, R.drawable.band, R.drawable.dana, R.drawable.drbardil,
        R.drawable.dosra, R.drawable.harf, R.drawable.hasil, R.drawable.hilale,
        R.drawable.humkahan, R.drawable.eman, R.drawable.kankr, R.drawable.kisjahn,
        R.drawable.koibat, R.drawable.lahasil, R.drawable.maat, R.drawable.mainykhwab,
        R.drawable.mano, R.drawable.merizat, R.drawable.mutthi, R.drawable.pagal,
        R.drawable.peer, R.drawable.qaid, R.drawable.sahar, R.drawable.shahre,
        R.drawable.teriyad, R.drawable.thorra, R.drawable.urran
        , R.drawable.wapsi, R.drawable.yejo, R.drawable.zindgi,R.drawable.husna,R.drawable.kisjahn)

    private val nimraImageRes = listOf(

        R.drawable.sans_sakin_thi,R.drawable.paras,R.drawable.pahharikaqaidi,R.drawable.mushaf,
        R.drawable.merykhab,R.drawable.mehrunisa,R.drawable.main_anmol,R.drawable.lapata,R.drawable.iblees
        ,R.drawable.hadd,R.drawable.beli,R.drawable.apniungli,R.drawable.ahmaq,R.drawable.halim,R.drawable.jannt,R.drawable.womera,R.drawable.qraqram)
    private val novletImageRes = listOf(

        R.drawable.gurria,R.drawable.wafa,R.drawable.kitnynadan,R.drawable.fasal,
        R.drawable.sawal,R.drawable.sun,R.drawable.dilki,R.drawable.dilka,R.drawable.bana
        ,R.drawable.basyun,R.drawable.ujala,R.drawable.alao,R.drawable.brother)
    private val yusraImageRes = listOf(

        R.drawable.u1,R.drawable.u2,R.drawable.u3,R.drawable.u4,
        R.drawable.u5,R.drawable.u6,R.drawable.u7,R.drawable.u16,R.drawable.u18
        ,R.drawable.u19,R.drawable.u20,R.drawable.u21,R.drawable.u22,R.drawable.u23)

    private val afsanaImageRes = listOf(

        R.drawable.yak,R.drawable.yar,R.drawable.wo,R.drawable.hppy,
        R.drawable.mura,R.drawable.makad,R.drawable.mghlta,R.drawable.mzhb,R.drawable.mahafiz,R.drawable.mubrk,R.drawable.court
        ,R.drawable.kmra,R.drawable.kambakht,R.drawable.qisa, R.drawable.zrort,R.drawable.sbha,R.drawable.shdi,R.drawable.sedi,
        R.drawable.sza,R.drawable.zndgi,R.drawable.rshta,R.drawable.rahmt,R.drawable.rano
        ,R.drawable.rajarani,R.drawable.rapinzl,R.drawable.depchly, R.drawable.dilchor,R.drawable.dilto,R.drawable.dagh,R.drawable.dasttan,
        R.drawable.daira,R.drawable.khair,R.drawable.hmaqtain,R.drawable.husne,R.drawable.jmalo
        ,R.drawable.samr,R.drawable.tees,R.drawable.bhu,R.drawable.bhook,  R.drawable.aunchy,R.drawable.ikpyara,R.drawable.afsa,R.drawable.appa,)





}


