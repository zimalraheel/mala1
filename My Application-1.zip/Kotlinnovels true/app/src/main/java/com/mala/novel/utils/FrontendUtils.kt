package com.mala.novel.utils

import android.widget.ImageView
import com.bumptech.glide.Glide

fun ImageView.loadOnline(imageUrl:String){
    Glide.with(this.context)
        .load(imageUrl)
     //  .transition(withCrossFade())
        .thumbnail(0.5f)
        .into(this)

}