package com.mala.novel.adapter

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.mala.novel.MainActivity
import com.mala.novel.R
import com.mala.novel.model.Datamodel


class Myadapter(var dataholder: ArrayList<Datamodel>, var activity: Activity) :
    RecyclerView.Adapter<Myadapter.myviewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): myviewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.single_row, parent, false)
        return myviewHolder(view)
    }

    override fun onBindViewHolder(
        holder: myviewHolder,
        @SuppressLint("RecyclerView") position: Int
    ) {
        holder.desc.text = dataholder[position].desc
        holder.itemView.setOnClickListener { v ->

                            when (position) {
                                0 -> {
                                    val activity = v.context as AppCompatActivity
                                    val intent = Intent(activity, MainActivity::class.java)
                                    activity.startActivity(intent)
                                  }
                                /** -> {
                                    val activity1 = v.context as AppCompatActivity

                                    gotoUrl("https://youtube.com/playlist?list=PLwQWxEBLPfYHtTXPrG6djNLA1dt22lRho&si=HzyC0gDuap-Q3O0W")

                                }*/


                                1-> {
                                    val activity1 = v.context as AppCompatActivity

                                    val intent1 = Intent(Intent.ACTION_SEND)
                                    intent1.setType("text/plain")
                                    val Body = "Download this app"
                                    val sub = "https://play.google.com/store/apps/details?id=com.icoms.sbook"
                                    intent1.putExtra(Intent.EXTRA_TEXT, Body)
                                    intent1.putExtra(Intent.EXTRA_TEXT, sub)
                                    activity1.startActivity(Intent.createChooser(intent1, "share using"))

                                }

                                2 -> {
                                    val activity2 = v.context as AppCompatActivity
                                    val newintent = Intent(
                                        Intent.ACTION_VIEW,
                                        Uri.parse("https://play.google.com/store/apps/details?id=com.mala.novel")
                                    )
                                    activity2.startActivity(newintent)
                                }

                                3 -> {
                                    val activity3 = v.context as AppCompatActivity
                                    val newintent = Intent(
                                        Intent.ACTION_VIEW,
                                        Uri.parse("https://play.google.com/store/apps/developer?id=Online+Math+Learning")
                                    )
                                    activity3.startActivity(newintent)
                                }
                            }
                        }
                    }

    private fun gotoUrl(s: String) {

        val uri = Uri.parse(s)
        activity.startActivity(Intent(Intent.ACTION_VIEW, uri))

    }


    override fun getItemCount(): Int {
        return dataholder.size
    }

    inner class myviewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var desc: TextView

        init {
            desc = itemView.findViewById(R.id.t2)
        }
    }
}
