package com.mala.novel.model

class exitmodel {
}