package com.mala.novel.repository

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.mala.novel.BooksModel
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.io.IOException

class DataRepo {

    val malaBooks: MutableStateFlow<List<BooksModel>> = MutableStateFlow(emptyList())
    val afsanaBooks: MutableStateFlow<List<BooksModel>> = MutableStateFlow(emptyList())
    val nimraBooks: MutableStateFlow<List<BooksModel>> = MutableStateFlow(emptyList())
    val novletBooks: MutableStateFlow<List<BooksModel>> = MutableStateFlow(emptyList())
    val umairaBooks: MutableStateFlow<List<BooksModel>> = MutableStateFlow(emptyList())
    val yusraBooks: MutableStateFlow<List<BooksModel>> = MutableStateFlow(emptyList())

     val allBooksModel = AllBooksModel()


    lateinit var malaDefferBooks: Deferred<Flow<BooksModel>>
    lateinit var afsanaDefferBooks: Deferred<Flow<BooksModel>>
    lateinit var nimraDefferBooks: Deferred<Flow<BooksModel>>

    suspend fun startParsingBooks(context: Context) {
        coroutineScope {
            malaDefferBooks = async { parseJson(jsonParser(context).malaBooks) }
            afsanaDefferBooks = async { parseJson(jsonParser(context).afsanaBooks) }
            nimraDefferBooks = async { parseJson(jsonParser(context).nimraBooks) }
            launch {
                try {
                    malaDefferBooks.await().collect { book ->
                        allBooksModel.malaBooks.add(book)
                    }
                    malaBooks.value = allBooksModel.malaBooks
                } catch (e: Exception) {
                    Log.e("TAG", "Error processing mala books: ${e.message}", e)
                }
            }
            launch {
                try {
                    afsanaDefferBooks.await().collect { book ->
                        Log.d("Testing", "afsana books size is ${allBooksModel.afsanaBooks.size} ")
                        Log.d("TAG", "Received afsana book: ${book.tittle}")
                        allBooksModel.afsanaBooks.add(book)
                    }
                    afsanaBooks.value = allBooksModel.afsanaBooks
                } catch (e: Exception) {
                    Log.e("TAG", "Error processing afsana books: ${e.message}", e)
                }
            }
            launch {
                try {
                    nimraDefferBooks.await().collect { book ->
                        Log.d("TAG", "Received nimra book: ${book.tittle}")
                        allBooksModel.nimraBooks.add(book)
                    }
                    nimraBooks.value = allBooksModel.nimraBooks
                } catch (e: Exception) {
                    Log.e("TAG", "Error processing nimra books: ${e.message}", e)
                }
            }

        }
    }


    private fun parseJson(booksModel: List<BooksModel>): Flow<BooksModel> = flow {
        val processedBooks = coroutineScope {
            booksModel.map { book ->
                async(Dispatchers.IO) {
//                    val downloadImage = getFinalUrl(book.image)
                    val downloadPdf = getFinalUrl(book.bookPdf)

                    BooksModel(
                        image = book.image,
                        bookPdf = downloadPdf,
                        description = book.description,
                        tittle = book.tittle,
                        author = book.author
                    )
                }
            }
        }
        processedBooks.forEach { emit(it.await()) }
    }

    private fun readJsonFromAssets(context: Context, fileName: String): String? {
        return try {
            context.assets.open(fileName).bufferedReader().use { it.readText() }
        } catch (ioException: IOException) {
            ioException.printStackTrace()
            null
        }
    }

    private fun jsonParser(context: Context): AllBooksModel {
        val jsonFileString = readJsonFromAssets(context, "allNovels.json")
        val gson = Gson()

        return gson.fromJson(jsonFileString, AllBooksModel::class.java)
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    private suspend fun getFinalUrl(url: String): String = withContext(Dispatchers.IO) {
        var finalUrl = ""
        try {
            val request = Request.Builder().url(url).build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e("TAG", "Failed to get initial response for URL: $url")
                    return@use finalUrl
                }

                val html = response.body?.string() ?: return@use finalUrl
                val doc: Document = Jsoup.parse(html)

                val linkToClick = doc.select("a#downloadButton.input.popsok").attr("href")

                if (linkToClick.isNotEmpty()) {
                    Log.d("TAG", "Found link: $linkToClick")

                    val followUpRequest = Request.Builder().url(linkToClick).build()

                    client.newCall(followUpRequest).execute().use { followUpResponse ->
                        if (followUpResponse.isSuccessful) {
                            finalUrl = followUpResponse.request.url.toString()
                        } else {
                            Log.d("TAG", "Failed to follow the link: $linkToClick")
                        }
                    }
                } else {
                    Log.d("TAG", "No link found with selector: for this url is $url")
                }
            }
        } catch (e: Exception) {
            Log.e("TAG", "Exception during URL resolution: ${e.message}", e)
        }
        return@withContext finalUrl
    }
}

data class AllBooksModel(
    val malaBooks: ArrayList<BooksModel> = ArrayList(),
    val afsanaBooks: ArrayList<BooksModel> = ArrayList(),
    val nimraBooks: ArrayList<BooksModel> = ArrayList(),
    val novletBooks: ArrayList<BooksModel> = ArrayList(),
    val umairaBooks: ArrayList<BooksModel> = ArrayList(),
    val yusraBooks: ArrayList<BooksModel> = ArrayList(),
)
