package com.mala.novel.repository

import android.app.DownloadManager
import android.content.ContentValues.TAG
import android.content.Context
import android.content.Context.DOWNLOAD_SERVICE
import android.net.Uri
import android.os.Environment
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.mala.novel.utils.MyResponses
import java.io.File

class BookRepo(val context: Context) {

    private val downloadLd = MutableLiveData<MyResponses<DownloadModel>>()
    val downloadLiveData get() = downloadLd

    fun downloadPdf(url: String, fileName: String) {
        val file = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), fileName)
        Log.i(TAG, "downloadPdf: ${file.absolutePath}")
        if (file.exists()) {
            val model = DownloadModel(
                progress = 100,
                isDownloaded = true,
                downloadId = -1,
                filePath = file.toURI().toString()
            )
            downloadLd.postValue(MyResponses.Success(model))
            Log.i(TAG, "downloadPdf: File Already Exist")
            return
        }
        downloadLd.postValue(MyResponses.Loading())


        val downloadManager = context.getSystemService(DOWNLOAD_SERVICE) as DownloadManager

        val downloadRequest = DownloadManager.Request(Uri.parse(url)).apply {
            setAllowedNetworkTypes(DownloadManager.Request.NETWORK_MOBILE or DownloadManager.Request.NETWORK_WIFI)
            setTitle(fileName)
            setDescription("Downloading Book")
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setAllowedOverRoaming(false)
            setAllowedOverMetered(true)
            setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, fileName)
        }

        val downloadId = downloadManager.enqueue(downloadRequest)

        var isDownloaded = false
        var progress = 0

        while (!isDownloaded) {
            val cursor = downloadManager.query(DownloadManager.Query().setFilterById(downloadId))
            if (cursor.moveToNext()) {
                val status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))

                when (status) {
                    DownloadManager.STATUS_RUNNING -> {
                        val totalSize =
                            cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                        if (totalSize > 0) {
                            val downloadedBytesSize =
                                cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                            progress = ((downloadedBytesSize * 100L) / totalSize).toInt()
                            downloadLd.postValue(MyResponses.Loading(progress))
                        }

                    }

                    DownloadManager.STATUS_FAILED -> {
                        val reason =
                            cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                        //  isDownloaded = true
                        downloadLd.postValue(MyResponses.Error("Failed to Download $fileName.\nReason $reason"))

                    }

                    DownloadManager.STATUS_SUCCESSFUL -> {
                        progress = 100
                        isDownloaded = true

                        val filePath =
                            cursor.getString(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI))
                        val model = DownloadModel(
                            progress = progress,
                            isDownloaded = isDownloaded,
                            downloadId = downloadId,
                            filePath = filePath
                        )
                        downloadLd.postValue(MyResponses.Success(model))


                    }

                    DownloadManager.STATUS_PENDING -> {
                        downloadLd.postValue(MyResponses.Loading(progress))
                        Log.i(TAG, "downloadPdf: Pending")
                    }

                    DownloadManager.STATUS_PAUSED -> {
                        downloadLd.postValue(MyResponses.Loading(progress))
                        Log.i(TAG, "downloadPdf: Paused")
                    }


                }


            }
        }


    }
}

data class DownloadModel(
    var progress: Int = 0,
    var isDownloaded: Boolean,
    var downloadId: Long,
    var filePath: String
)

