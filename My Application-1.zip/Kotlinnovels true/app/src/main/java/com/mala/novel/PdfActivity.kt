package com.mala.novel

import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.mala.novel.databinding.ActivityPdfBinding
import com.mala.novel.fregmnt.PdfToolsFragment
import com.github.barteksc.pdfviewer.scroll.DefaultScrollHandle
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.MobileAds
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PdfActivity : AppCompatActivity() {
    val activity = this
    lateinit var  binding: ActivityPdfBinding
    val bookPdf = "sample_book.pdf"
    val bookId = "sample_book.pdf"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding= ActivityPdfBinding.inflate(layoutInflater)

        enableEdgeToEdge()
        this.window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(binding.root)


        val backgroundScope = CoroutineScope(Dispatchers.IO)
        backgroundScope.launch {
             MobileAds.initialize(this@PdfActivity) {}


        }
        // Start loading the ad in the background.
        val adRequest = AdRequest.Builder().build()
        binding.bannerAdView1.loadAd(adRequest)
        supportActionBar?.hide()
        setupBasicViews()
        binding.apply {
            val bookPdf = intent.getStringExtra("book_pdf").toString()
            pdfView.fromUri(Uri.parse(bookPdf))
                .swipeHorizontal(false)
                .scrollHandle(DefaultScrollHandle(activity))
                .enableSwipe(true)
                .pageSnap(true).autoSpacing(true).pageFling(true)
                .enableSwipe(true)
                .enableDoubletap(true)
                .defaultPage(0)
                .enableAnnotationRendering(true)
                .enableAntialiasing(true)
                .spacing(0)
                .fitEachPage(true)
                .pageSnap(true)
                .pageFling(true)

                .load()
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }


    private fun setupBasicViews() {
        binding.mToolsFab.setOnClickListener {
            val toolsBottomSheet = PdfToolsFragment()
            toolsBottomSheet.show(supportFragmentManager, toolsBottomSheet.tag)
        }

    }


}
