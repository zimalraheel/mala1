package com.mala.novel.model

import androidx.annotation.DrawableRes
import com.mala.novel.enums.ToolsType

data class ToolsModel(
    val title: String,
    @DrawableRes
    val image: Int,
    val type: ToolsType
)
