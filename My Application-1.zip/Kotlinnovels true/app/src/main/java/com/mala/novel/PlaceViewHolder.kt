package com.mala.novel

class PlaceViewHolder
