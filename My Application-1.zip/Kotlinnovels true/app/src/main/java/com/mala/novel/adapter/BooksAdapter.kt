package com.mala.novel.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mala.novel.BooksModel
import com.mala.novel.databinding.ItemBookBinding

class BooksAdapter (
    val list: ArrayList<BooksModel>,
    val context: Context,

    ):RecyclerView.Adapter<BooksAdapter.ViewHolder>() {
    class ViewHolder(val binding: ItemBookBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(ItemBookBinding.inflate(LayoutInflater.from(context), parent, false))
    }

    override fun getItemCount() = list.size


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val model = list[position]
        holder.binding.apply {
            imageView.setImageResource(model.imageRes)


            }

        }
    }
