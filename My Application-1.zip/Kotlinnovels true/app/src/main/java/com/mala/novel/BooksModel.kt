package com.mala.novel

import java.io.Serializable

data class BooksModel (
    var imageRes: Int = 0,
    val image: String,
    val tittle: String,
    val description: String,
    val author: String,
    var bookPdf: String,
    var isPdfAvailable : Boolean = false
): Serializable
