package com.mala.novel.enums

enum class ToolsType {
    BOOKMARKS,
    ADD_TO_BOOKMARKS,
    NOTES,
    NIGHT_MODE,
}