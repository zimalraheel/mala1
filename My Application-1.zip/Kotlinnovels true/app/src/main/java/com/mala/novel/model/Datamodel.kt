package com.mala.novel.model

class Datamodel(@JvmField var desc: String)
