package com.mala.novel.model

import com.mala.novel.BooksModel
import com.mala.novel.adapter.LAYOUT_HOME


data class HomeModel(
    val catTitle:String?=null,
    val booksList:ArrayList<BooksModel>?=null,

    var bod:BooksModel?=null,
    val LAYOUT_TYPE:Int = LAYOUT_HOME
)
