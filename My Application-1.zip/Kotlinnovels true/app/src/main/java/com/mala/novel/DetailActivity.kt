package com.mala.novel

import android.app.ActionBar
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModelProvider
import com.mala.novel.databinding.ActivityDetailBinding
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.mala.novel.repository.BookRepo
import com.mala.novel.utils.MyResponses
import com.mala.novel.viewModels.BookViewModel
import com.mala.novel.viewModels.BookViewModelFactory
import com.mala.novel.databinding.LayoutProgressBinding

class DetailActivity : AppCompatActivity() {

    lateinit var binding: ActivityDetailBinding
    private var mInterstitialAd: InterstitialAd? = null

    val activity = this


    private val repo = BookRepo(activity)
    private val viewModel by lazy {
        ViewModelProvider(
            activity,
            BookViewModelFactory(repo)
        )[BookViewModel::class.java]
    }
    private val TAG = "Details_Activity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDetailBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        supportActionBar?.hide()

        MobileAds.initialize(this)

        val adRequest = AdRequest.Builder().build()

        InterstitialAd.load(
            this,
            resources.getString(R.string.inter),
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    mInterstitialAd = null
                }

                override fun onAdLoaded(interstitialAd: InterstitialAd) {
                    mInterstitialAd = interstitialAd
                }
            })


        val bookModel = intent.getSerializableExtra("book_model") as BooksModel


        binding.apply {

            bookModel.apply {
                mBookTitle.text = tittle
                mAuthorName.text = author
                mBookDesc.text = description
                mBookImage.drawable
                mBookImage.setImageResource(imageRes)

              //  mBookImage.loadOnline(image)
            }


            binding.mReadBookBtn.setOnClickListener {

                if (mInterstitialAd != null)
                    mInterstitialAd!!.show(this@DetailActivity)

                mInterstitialAd?.fullScreenContentCallback = object : FullScreenContentCallback() {

                    override fun onAdDismissedFullScreenContent() {
                        viewModel.downloadFile(bookModel.bookPdf, "${bookModel.tittle}.pdf")

                        mInterstitialAd = null
                    }

                    override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                        viewModel.downloadFile(bookModel.bookPdf, "${bookModel.tittle}.pdf")
                        mInterstitialAd = null
                    }

                }

                viewModel.downloadFile(bookModel.bookPdf, "${bookModel.tittle}.pdf")
            }
            val dialogBinding = LayoutProgressBinding.inflate(layoutInflater)
            val dialog = Dialog(activity).apply {
                setCancelable(false)
                setContentView(dialogBinding.root)

                this.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                this.window!!.setLayout(
                    ActionBar.LayoutParams.MATCH_PARENT,
                    ActionBar.LayoutParams.WRAP_CONTENT
                )
            }

            viewModel.downloadLiveData.observe(activity) {
                when (it) {
                    is MyResponses.Error -> {
                        dialog.dismiss()
                        Log.e(TAG, "onCreate: ${it.errorMessage}")
                    }

                    is MyResponses.Loading -> {
                        dialogBinding.mProgress.text = "${it.progress}%"
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                            dialogBinding.mProgressBar.setProgress(it.progress, true)
                        } else {
                            dialogBinding.mProgressBar.progress = it.progress
                        }
                        dialog.show()
                        Log.i(TAG, "onCreate: Progress ${it.progress}")

                    }

                    is MyResponses.Success -> {
                        //  activity.loadAndShowInterstitialAdWithProgressDialog(customCode = {
                        dialog.dismiss()
                        Log.i(TAG, "onCreate: Downloaded ${it.data}")
                        Intent().apply {
                            putExtra("book_pdf", it.data?.filePath)
                            //    putExtra("book_id", "${bookModel.title}_${bookModel.author}")
                            setClass(activity, PdfActivity::class.java)
                            startActivity(this)
                        }
//                        viewModel.downloadLiveData.value = MyResponses.Loading()
                    }
                    //)

                }
            }
            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
                insets
            }
        }
    }
}

